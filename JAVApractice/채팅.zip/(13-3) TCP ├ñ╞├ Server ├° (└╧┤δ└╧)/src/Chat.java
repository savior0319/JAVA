import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.DefaultListModel;

public class Chat extends Thread {

	ServerSocket serverSocket;
	Socket socket;
	DataInputStream in;
	DataOutputStream out;
	DefaultListModel<String> model;	// UI�� �������� �߰��ϱ� ����...
	
	boolean isCheck = true;
	
	public Chat(DefaultListModel<String> model, int port) {
		this.model = model;		// �����ڸ� ���� DefaultListModel ��ü ��������
		try {
			serverSocket = new ServerSocket(port);
			socket = serverSocket.accept();
			in = new DataInputStream(socket.getInputStream());
			out = new DataOutputStream(socket.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void sendMsg(String msg) {
		try {
			out.writeUTF(msg);
			out.flush();
			model.addElement("����(��) : "+msg);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		try {
			while(isCheck) {
				String msg = in.readUTF();
				model.addElement("���� : "+msg);
			}
		} catch (Exception e) {
			close();
			e.printStackTrace();
		}
	}
	
	private void close() {
		isCheck = false;
		try {
			if(in != null) {
				in.close();
				in = null;
			}
			if(out != null) {
				out.close();
				out = null;
			}
			if(socket != null) {
				socket.close();
				socket = null;
			}
		} catch (IOException e) {
		}
	}
	
}
