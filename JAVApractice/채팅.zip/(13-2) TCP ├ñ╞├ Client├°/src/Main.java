import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class Main extends JFrame {

	DefaultListModel<String> model = new DefaultListModel<>();
	JList<String> list = new JList<>(model);
	JScrollPane pane = new JScrollPane(list);
	JTextField tfChat = new JTextField();
	JButton btnLogin = new JButton("����");
	JButton btnSend = new JButton("������");
	
	Chat chat;
	
	public Main() {
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel(new GridLayout(2, 3));
		JPanel panel2 = new JPanel(new GridLayout(1, 1));
		JPanel panel3 = new JPanel(new BorderLayout());
		
		JTextField tfServerPort = new JTextField();
		JTextField tfServerIP = new JTextField();
		
		btnLogin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				chat = new Chat(model, tfServerIP.getText(), Integer.parseInt(tfServerPort.getText()));
				chat.start();
			}
		});
		
		btnSend.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				chat.sendMsg(tfChat.getText());
				tfChat.setText("");
			}
		});
		
		panel1.add(new JLabel("Server IP", JLabel.CENTER));
		panel1.add(new JLabel("Server Port", JLabel.CENTER));
		panel1.add(new JLabel("", JLabel.CENTER));
		panel1.add(tfServerIP);
		panel1.add(tfServerPort);
		panel1.add(btnLogin);
		panel2.add(pane);
		panel3.add(new JLabel(" ä�� "), BorderLayout.WEST);
		panel3.add(tfChat, BorderLayout.CENTER);
		panel3.add(btnSend, BorderLayout.EAST);
		
		c.add(panel1, BorderLayout.NORTH);
		c.add(panel2, BorderLayout.CENTER);
		c.add(panel3, BorderLayout.SOUTH);
		
		setTitle("TCP ä�� Client ��");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(300, 400);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Main();
	}

}
