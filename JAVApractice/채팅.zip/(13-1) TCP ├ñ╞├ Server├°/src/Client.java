import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

public class Client implements Runnable {

	Socket socket;
	DataInputStream in;
	DataOutputStream out;
	ArrayList<Client> clientList;
	String ip;

	boolean isCheck = true;

	public Client(Socket socket, ArrayList<Client> list) {
		this.socket = socket;
		this.clientList = list;
		this.ip = socket.getInetAddress().toString();

		try {
			in = new DataInputStream(socket.getInputStream());
			out = new DataOutputStream(socket.getOutputStream());
		} catch (IOException e) {
		}

		clientList.add(this);
		System.out.println(this.ip + " Client ����");
		System.out.println("���� ���� Client �� : " + clientList.size());
	}

	@Override
	public void run() {
		try {
			while (isCheck) {
				String msg = in.readUTF();
				System.out.println(this.ip + "���� ���� �޽��� :: " + msg);
				for (Client client : clientList) {
					String ip = client.socket.getInetAddress().toString();
					if (!ip.equals(this.ip)) {
						client.sendMsg(ip + " : " + msg);
						System.out.println("Send Massage :: " + this.ip + " -> " + ip);
					}
				}
			}
		} catch (IOException e) {
			close();
		}
	}

	public void sendMsg(String msg) {
		try {
			out.writeUTF(msg);
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void close() {
		isCheck = false;
		clientList.remove(this);
		try {
			if (in != null) {
				in.close();
				in = null;
			}
			if (out != null) {
				out.close();
				out = null;
			}
			if (socket != null) {
				socket.close();
				socket = null;
			}
		} catch (IOException e) {
		}
		System.out.println(this.ip + " Client ����");
		System.out.println("���� ���� Client �� : " + clientList.size());
	}

}
