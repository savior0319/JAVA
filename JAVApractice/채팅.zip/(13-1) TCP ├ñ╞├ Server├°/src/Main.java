import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Main {

	public Main() throws IOException {
		final int port = 2224;
		final ArrayList<Client> clientList = new ArrayList<>();
		
		ServerSocket server = new ServerSocket(port);
		
		while(true) {
			boolean isCheck = true;
			Socket socket = server.accept();
			for (Client client : clientList) {
				String ip = client.socket.getInetAddress().toString();
				if(ip.equals(socket.getInetAddress().toString())) {
					System.out.println(ip + " Client ���� ���� (�ߺ�)");
					System.out.println("���� ���� Client �� : " + clientList.size());
					isCheck = false;
					break;
				}
			}
			if(!isCheck) continue;
			Client client = new Client(socket, clientList);
			Thread thread = new Thread(client);
			thread.start();
		}
	}
	
	public static void main(String[] args) {
		try {
			new Main();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
